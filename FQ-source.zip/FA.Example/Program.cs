﻿using FQ.API;
using System;
using System.Collections.Generic;
using System.Data;
using System.IO;
using System.Reflection;
using System.Text;


namespace FA.Example
{
    class Program
    {
        static void Main(string[] args)
        {
            string libreOfficePath = @"C:\Users\nitipanp\Downloads\LibreOfficePortable\LibreOfficeCalcPortable.exe";

            Random rand = new Random();

            string path = Path.Combine(new FileInfo(Assembly.GetExecutingAssembly().Location).DirectoryName, "Quotation Template.xlsx");

            List<QuotationItem> items = new List<QuotationItem>();

            for (int i = 0; i < 25; i++)
            {
                items.Add(new QuotationItem
                {
                    Address = "111/999 Address Bangkok Thaiand",
                    BuildingName = "Building Name",
                    ItemName = "Product Wifi ABC",
                    Media = "Fiber",
                    Price = i % 4 == 0 ? rand.Next(1, 1000) * 10000 : 0,
                    Router = "Router Test",
                    Speed = "100/100"
                });
            }



            FQTools.GenerateQuotation(libreOfficePath, path, @"C:\FQ\FA.Example\bin\Debug\quotation_12.pdf", new QuotationHeader
            {
                SalesPerson = "นิติพันธ์",
                ContactNumber = "083-447-0116",
                SaleContactNumber = "123-444-5555",
                ApprovedBy = "Sales/Sr. Account Executive",
                TermOfPayment = "30 days",
                Attention = "Nitipan Pompan",
                DeliveryDate = "30-40 days",
                Date = DateTime.Now,
                Email = "nitipan.p@hotmail.com",
                QuotationFor = "MyCompany (Thailand) Co., Ltd.",
                QuoteValidity = "15 days",
                QuotationRefNo = "SU1-1234-1234-999-ABCD",
                CustomerEmail = "customer@com.org",
                ContactPeriod = "15"
            }, items, "Product 1234", "(เอกสารตามไฟล์แนบ)");

        }

        static void Main_Encryption(string[] args)
        {
            // protect
            FQTools.ProtectFile("FlashQuotationData.xlsx", "FlashQuotationData.protected.xlsx.");

            // unprotect
            FQTools.UnProtectFile("FlashQuotationData.protected.xlsx", "FlashQuotationData.unprotected.xlsx.");


            // check original & unprotected file are equal ?
            string original = FQTools.CheckSum("FlashQuotationData.xlsx");
            string unprotected = FQTools.CheckSum("FlashQuotationData.unprotected.xlsx");

            if (original != unprotected)
                throw new Exception("Encryption error !");
        }
    }
}
