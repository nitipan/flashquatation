﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Linq;
using System.Security;
using System.Security.Cryptography;
using System.IO;
using System.Runtime.InteropServices;
using System.Data;
using OfficeOpenXml;
using System.Diagnostics;
using System.Drawing;
using System.Threading;
using System.Reflection;
using System.Globalization;

namespace FQ.API
{
    public sealed class FQTools
    {

        private const string KeyFile = ".key";
        private const string VectorFile = ".vector";

        /// <summary>
        /// Protect a file with Encrt
        /// </summary>
        /// <param name="inputFilename">Input file name (ex. FlashQuotationData.xlsx)</param>
        /// <param name="outputFilename">Output file name (ex. FlashQuotationData.protected.xlsx)</param>
        /// <returns></returns>
        public static void ProtectFile(string inputFilename, string outputFilename)
        {
            try
            {

                string key = string.Empty;
                string iv = string.Empty;

                if (!File.Exists(KeyFile) || !File.Exists(VectorFile))
                {
                    using (var aes = new RijndaelManaged())
                    {
                        aes.KeySize = 256;

                        aes.GenerateKey();
                        aes.GenerateIV();

                        File.WriteAllText(KeyFile, Convert.ToBase64String(aes.Key));
                        File.WriteAllText(VectorFile, Convert.ToBase64String(aes.IV));
                    }
                }

                key = File.ReadAllText(KeyFile);
                iv = File.ReadAllText(VectorFile);

                using (var algorithm = new RijndaelManaged())
                {
                    algorithm.Key = Convert.FromBase64String(key);
                    algorithm.IV = Convert.FromBase64String(iv);
                    algorithm.Mode = CipherMode.CBC;
                    algorithm.Padding = PaddingMode.PKCS7;

                    ICryptoTransform encryptor = algorithm.CreateEncryptor(algorithm.Key, algorithm.IV);

                    using (FileStream fsInput = new FileStream(inputFilename, FileMode.Open, FileAccess.Read))
                    {
                        using (FileStream fsEncrypted = new FileStream(outputFilename, FileMode.Create, FileAccess.Write))
                        {
                            using (CryptoStream cryptostream = new CryptoStream(fsEncrypted, encryptor, CryptoStreamMode.Write))
                            {
                                byte[] bytearrayinput = new byte[fsInput.Length];
                                fsInput.Read(bytearrayinput, 0, bytearrayinput.Length);
                                cryptostream.Write(bytearrayinput, 0, bytearrayinput.Length);

                            }
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        /// <summary>
        /// Protect a file with Encrt
        /// </summary>
        /// <param name="protectedFilename">Input file name which already protected (ex. FlashQuotationData.protected.xlsx)</param>
        /// <param name="outputFilename">Output file name (ex. FlashQuotationData.xlsx)</param>
        /// <returns></returns>
        public static void UnProtectFile(string protectedFilename, string outputFilename)
        {
            try
            {

                string key = string.Empty;
                string iv = string.Empty;

                if (!File.Exists(KeyFile) || !File.Exists(VectorFile))
                {
                    throw new NullReferenceException("Could not find Key or Vector file, please re-encrypte the file.");
                }

                key = File.ReadAllText(KeyFile);
                iv = File.ReadAllText(VectorFile);

                using (var algorithm = new RijndaelManaged())
                {
                    algorithm.Key = Convert.FromBase64String(key);
                    algorithm.IV = Convert.FromBase64String(iv);
                    algorithm.Mode = CipherMode.CBC;
                    algorithm.Padding = PaddingMode.PKCS7;

                    ICryptoTransform encryptor = algorithm.CreateDecryptor(algorithm.Key, algorithm.IV);

                    using (FileStream fsInput = new FileStream(protectedFilename, FileMode.Open, FileAccess.Read))
                    {
                        using (FileStream fsEncrypted = new FileStream(outputFilename, FileMode.Create, FileAccess.Write))
                        {
                            using (CryptoStream cryptostream = new CryptoStream(fsEncrypted, encryptor, CryptoStreamMode.Write))
                            {
                                byte[] bytearrayinput = new byte[fsInput.Length];
                                fsInput.Read(bytearrayinput, 0, bytearrayinput.Length);
                                cryptostream.Write(bytearrayinput, 0, bytearrayinput.Length);

                            }
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }


        public static string CheckSum(string filename)
        {
            using (var md5 = MD5.Create())
            {
                using (var stream = File.OpenRead(filename))
                {
                    return Convert.ToBase64String(md5.ComputeHash(stream));
                }
            }
        }

        /// <summary>
        /// Generate qoutation to pdf file based on excel template
        /// </summary>
        /// <param name="libreOffficeExePath">Path of Libreoffice (ex. C:\LibreOfficeCalcPortable.exe)</param>
        /// <param name="templateFile">XML template file</param>
        /// <param name="outputPdf">Output file in PDF format</param>
        /// <param name="header">Information to be available in header</param>
        /// <param name="items">product items</param>
        /// <param name="attachmentProduct">Show product name incase of attachment available</param>
        /// <param name="attachmentText">Show text incase of attachment available</param>
        public static void GenerateQuotation(
            string libreOffficeExePath,
            string templateFile,
            string outputPdf,
            QuotationHeader header, List<QuotationItem> items, string attachmentProduct, string attachmentText)
        {
            header.Date = DateTime.Now;
            string temp = Guid.NewGuid().ToString() + ".xlsx";

            var tempFolder = Path.Combine(new FileInfo(Assembly.GetExecutingAssembly().Location).DirectoryName, "Temp");

            if (!Directory.Exists(tempFolder))
                Directory.CreateDirectory(tempFolder);

            string tempFile = Path.Combine(tempFolder, temp);
            File.Copy(templateFile, tempFile);


            ExcelPackage output = new ExcelPackage(new FileInfo(tempFile));

            var centerStyle = output.Workbook.Styles.CreateNamedStyle("Center");
            centerStyle.Style.HorizontalAlignment = OfficeOpenXml.Style.ExcelHorizontalAlignment.Center;


            var rightStyle = output.Workbook.Styles.CreateNamedStyle("Right");
            rightStyle.Style.HorizontalAlignment = OfficeOpenXml.Style.ExcelHorizontalAlignment.Right;



            if (items.Count <= 10)
            {
                string selectedSheet = "Quotation";

                var sheet = output.Workbook.Worksheets[selectedSheet];
                FillGeneralInfo(header, sheet, true, true, 0, 1);


                int row = 21;

                int sum = FillItem(items, sheet, ref row, false);

                sheet.Cells["CA61"].Value = sum;
                sheet.Cells["CA61:CI61"].Merge = true;
                sheet.Cells["CA61:CI61"].Style.Numberformat.Format = "#,##0";


                output.Workbook.Worksheets.Delete("(Attachment)");

            }
            else
            {
                string selectedSheet = "Quotation";

                var coverSheet = output.Workbook.Worksheets[selectedSheet];

                FillGeneralInfo(header, coverSheet, true, true, 0, 1);

                var attachSheet = output.Workbook.Worksheets["(Attachment)"];
                FillGeneralInfo(header, attachSheet, false, false, -2, 1);

                int row = 16;
                int sum = FillItem(items, attachSheet, ref row, true);

                coverSheet.Cells["B21"].Value = 1;
                coverSheet.Cells["F21"].Value = attachmentProduct;
                coverSheet.Cells["F22"].Value = attachmentText;


                coverSheet.Cells["CA61"].Value = sum;
                coverSheet.Cells["CA61:CI61"].Merge = true;
                coverSheet.Cells["CA61:CI61"].Style.Numberformat.Format = "#,##0";

                coverSheet.Cells["CA20"].Value = sum;
                coverSheet.Cells["CA20:CI20"].Merge = true;
                coverSheet.Cells["CA20:CI20"].Style.Numberformat.Format = "#,##0";

                attachSheet.Cells["CA" + row].Value = sum;
                attachSheet.Cells["CA" + row + ":CI" + row].Merge = true;
                attachSheet.Cells["CA" + row + ":CI" + row].Style.Numberformat.Format = "#,##0";

            }


            output.Save();
            output.Dispose();


            var startInfo = new ProcessStartInfo(libreOffficeExePath, string.Format(" -headless -invisible --convert-to pdf:calc_pdf_Export  \"{0}\" --outdir \"{1}\"", Path.Combine(tempFolder, temp), tempFolder));

            startInfo.WorkingDirectory = new FileInfo(Assembly.GetExecutingAssembly().Location).DirectoryName;
            startInfo.UseShellExecute = false;

            Process process = Process.Start(startInfo);
            process.WaitForExit();

            bool outputFound = false;
            do
            {

                outputFound = File.Exists(Path.Combine(tempFolder, temp.Replace(".xlsx", ".pdf")));

                Thread.Sleep(1000);

            } while (!outputFound);

            if (File.Exists(outputPdf))
                File.Delete(outputPdf);

            File.Move(Path.Combine(tempFolder, temp.Replace(".xlsx", ".pdf")), outputPdf);
            File.Delete(Path.Combine(tempFolder, temp));

        }

        private static int FillItem(List<QuotationItem> items, ExcelWorksheet sheet, ref int row, bool allowAppend)
        {
            int startRow = row;

            int sum = 0;

            int itemNumber = 1;

            // fill item
            for (int i = 1; i <= items.Count; i++)
            {
                var item = items[i - 1];

                if (allowAppend)
                {
                    sheet.InsertRow(row, 4);


                    if (i % 15 == 0)
                    {

                        sheet.Cells["A" + (row - 1).ToString() + ":CJ" + (row - 1).ToString()].Style.Border.Bottom.Style = OfficeOpenXml.Style.ExcelBorderStyle.Thin;

                        sheet.Row(row - 1).PageBreak = true;
                    }
                }

                if (item.Price != 0)
                {
                    sheet.SetValue("B" + row.ToString(), itemNumber.ToString());
                    itemNumber++;
                }

                sheet.SetValue("F" + row.ToString(), item.ItemName);
                sheet.SetValue("F" + (row + 1).ToString(), item.BuildingName);
                sheet.SetValue("F" + (row + 2).ToString(), item.Address);

                sheet.Cells["AW" + row].Value = item.Media;
                sheet.Cells[string.Format("AW{0}:BA{0}", row)].Merge = true;
                sheet.Cells[string.Format("AW{0}:BA{0}", row)].StyleName = "Center";


                sheet.Cells["BB" + row].Value = item.Speed;
                sheet.Cells[string.Format("BB{0}:BG{0}", row)].Merge = true;
                sheet.Cells[string.Format("BB{0}:BG{0}", row)].StyleName = "Center";

                sheet.Cells["AW" + row].Style.Border.Left.Style = OfficeOpenXml.Style.ExcelBorderStyle.Thin;
                sheet.Cells["BA" + row].Style.Border.Right.Style = OfficeOpenXml.Style.ExcelBorderStyle.Thin;
                sheet.Cells["BG" + row].Style.Border.Right.Style = OfficeOpenXml.Style.ExcelBorderStyle.Thin;

                sheet.SetValue("BI" + row.ToString(), item.Router);

                if (item.Price != 0)
                    sheet.Cells["CA" + row.ToString()].Value = item.Price;

                sheet.Cells[string.Format("CA{0}:CI{0}", row)].Merge = true;
                sheet.Cells[string.Format("CA{0}:CI{0}", row)].Style.Numberformat.Format = "#,##0";

                sum += item.Price;

                if (allowAppend)
                {
                    for (int b = row; b < row + 4; b++)
                    {
                        sheet.Cells["A" + b.ToString()].Style.Border.Left.Style = OfficeOpenXml.Style.ExcelBorderStyle.Thin;
                        sheet.Cells["D" + b.ToString()].Style.Border.Right.Style = OfficeOpenXml.Style.ExcelBorderStyle.Thin;

                        sheet.Cells["AW" + b].Style.Border.Left.Style = OfficeOpenXml.Style.ExcelBorderStyle.Thin;
                        sheet.Cells["BA" + b].Style.Border.Right.Style = OfficeOpenXml.Style.ExcelBorderStyle.Thin;
                        sheet.Cells["BG" + b].Style.Border.Right.Style = OfficeOpenXml.Style.ExcelBorderStyle.Thin;

                        sheet.Cells["BY" + b.ToString()].Style.Border.Right.Style = OfficeOpenXml.Style.ExcelBorderStyle.Thin;
                        sheet.Cells["CJ" + b.ToString()].Style.Border.Right.Style = OfficeOpenXml.Style.ExcelBorderStyle.Thin;
                    }
                }

                row += 4;
            }
            return sum;
        }

        private static void FillGeneralInfo(QuotationHeader header, ExcelWorksheet sheet, bool footer, bool paymentTerm, int rowMargin, int saleRepresentativeMargin = 0)
        {

            sheet.Cells["N" + (10 + rowMargin)].StyleName = "Right";
            sheet.Cells["N" + (10 + rowMargin)].Style.Font.Bold = true;

            sheet.Cells["N" + (11 + rowMargin)].StyleName = "Right";
            sheet.Cells["N" + (11 + rowMargin)].Style.Font.Bold = true;

            sheet.Cells["N" + (12 + rowMargin)].StyleName = "Right";
            sheet.Cells["N" + (12 + rowMargin)].Style.Font.Bold = true;

            sheet.Cells["N" + (13 + rowMargin)].StyleName = "Right";
            sheet.Cells["N" + (13 + rowMargin)].Style.Font.Bold = true;
         
            sheet.Cells["BG" + (10 + rowMargin)].StyleName = "Right";
            sheet.Cells["BG" + (10 + rowMargin)].Style.Font.Bold = true;

            sheet.Cells["BG" + (11 + rowMargin)].StyleName = "Right";
            sheet.Cells["BG" + (11 + rowMargin)].Style.Font.Bold = true;

            sheet.Cells["BG" + (12 + rowMargin)].StyleName = "Right";
            sheet.Cells["BG" + (12 + rowMargin)].Style.Font.Bold = true;


            sheet.Cells["BH" + (10 + rowMargin)].Style.Font.Bold = false;
            sheet.Cells["BH" + (11 + rowMargin)].Style.Font.Bold = false;
            sheet.Cells["BH" + (12 + rowMargin)].Style.Font.Bold = false;


            sheet.SetValue("O" + (10 + rowMargin), header.QuotationFor);
            sheet.SetValue("O" + (11 + rowMargin), header.Attention);
            sheet.SetValue("O" + (12 + rowMargin), header.ContactNumber);

            sheet.SetValue("BH" + (10 + rowMargin + saleRepresentativeMargin), header.SalesPerson);
            sheet.SetValue("BH" + (11 + rowMargin + saleRepresentativeMargin), header.SaleContactNumber);
            sheet.SetValue("BH" + (12 + rowMargin + saleRepresentativeMargin), header.Email);




            sheet.Cells["O" + (13 + rowMargin)].Value = header.CustomerEmail;

            if (paymentTerm)
            {
                sheet.Cells["K64"].Value = header.ContactPeriod;
                sheet.Cells["K64"].StyleName = "Center";

                sheet.Cells["A16:AN16"].Merge = true;
                sheet.Cells["A16:AN16"].StyleName = "Center";
                sheet.SetValue("A16", header.QuotationRefNo);

                sheet.Cells["A16"].Style.Border.Left.Style = OfficeOpenXml.Style.ExcelBorderStyle.Thin;
                sheet.Cells["A16"].Style.Border.Right.Style = OfficeOpenXml.Style.ExcelBorderStyle.Thin;
                sheet.Cells["A16"].Style.Border.Bottom.Style = OfficeOpenXml.Style.ExcelBorderStyle.Thin;



                sheet.Cells["U16"].Style.Border.Left.Style = OfficeOpenXml.Style.ExcelBorderStyle.Thin;
                sheet.Cells["U16"].Style.Border.Right.Style = OfficeOpenXml.Style.ExcelBorderStyle.Thin;
                sheet.Cells["U16"].Style.Border.Bottom.Style = OfficeOpenXml.Style.ExcelBorderStyle.Thin;

                sheet.Cells["AO16:BG16"].Merge = true;
                sheet.Cells["AO16:BG16"].StyleName = "Center";
                sheet.Cells["AO16"].Style.Border.Left.Style = OfficeOpenXml.Style.ExcelBorderStyle.Thin;
                sheet.Cells["AO16"].Style.Border.Bottom.Style = OfficeOpenXml.Style.ExcelBorderStyle.Thin;
                sheet.SetValue("AO16", header.TermOfPayment);

                sheet.SetValue("CB16", header.Date.ToString("dd-MMM-yy", new CultureInfo("en-US")));


            }

            //if (footer)
            //{

            //}
            //else
            //{
            //    sheet.Cells["M" + (10 + rowMargin)].StyleName = "Right";
            //    sheet.Cells["M" + (10 + rowMargin)].Style.Font.Bold = true;

            //    sheet.Cells["M" + (11 + rowMargin)].StyleName = "Right";
            //    sheet.Cells["M" + (11 + rowMargin)].Style.Font.Bold = true;

            //    sheet.Cells["M" + (12 + rowMargin)].StyleName = "Right";
            //    sheet.Cells["M" + (12 + rowMargin)].Style.Font.Bold = true;

            //    sheet.Cells["M" + (13 + rowMargin)].StyleName = "Right";
            //    sheet.Cells["M" + (13 + rowMargin)].Style.Font.Bold = true;


            //    sheet.Cells["BI" + (10 + rowMargin)].StyleName = "Right";
            //    sheet.Cells["BI" + (10 + rowMargin)].Style.Font.Bold = true;

            //    sheet.Cells["BI" + (11 + rowMargin)].StyleName = "Right";
            //    sheet.Cells["BI" + (11 + rowMargin)].Style.Font.Bold = true;

            //    sheet.Cells["BI" + (12 + rowMargin)].StyleName = "Right";
            //    sheet.Cells["BI" + (12 + rowMargin)].Style.Font.Bold = true;
            //}

            sheet.Cells["BY3"].StyleName = "Right";
            sheet.Cells["BY4"].StyleName = "Right";
            sheet.Cells["BY5"].StyleName = "Right";


            if (footer)
            {

                sheet.Cells["C79:W79"].Merge = true;
                sheet.Cells["C79:W79"].StyleName = "Center";
                sheet.SetValue("C79", header.SalesPerson);

                sheet.Cells["AB80:AW80"].Merge = true;
                sheet.Cells["AB80:AW80"].StyleName = "Center";
                sheet.SetValue("AB80", header.ApprovedBy);

                if (header.ApprovedBy == "Sales/Sr. Account Executive")
                {
                    sheet.Cells["AB79:AW79"].Merge = true;
                    sheet.Cells["AB79:AW79"].StyleName = "Center";
                    sheet.SetValue("AB79", header.SalesPerson);

                }

                sheet.Cells["BG79:CB79"].Merge = true;
                sheet.Cells["BG79:CB79"].StyleName = "Center";
                sheet.SetValue("BG79", header.Attention);
            }

            sheet.Cells["AT" + (9 + rowMargin) + ":CJ" + (9 + rowMargin)].Style.Border.Bottom.Style = OfficeOpenXml.Style.ExcelBorderStyle.Thin;
            if (paymentTerm)
            {
                // fix border
                sheet.Cells["A13:AR13"].Style.Border.Bottom.Style = OfficeOpenXml.Style.ExcelBorderStyle.Thin;

            }

            if (!footer)
            {
                sheet.Cells["A11:AQ11"].Style.Border.Bottom.Style = OfficeOpenXml.Style.ExcelBorderStyle.Thin;
            }
        }
    }
}
