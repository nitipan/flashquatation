﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace FQ.API
{
    public sealed class QuotationHeader
    {
        public string QuotationFor { get; set; }

        public string Attention { get; set; }

        public DateTime Date { get; set; }

        public string SalesPerson { get; set; }

        public string ContactNumber { get; set; }

        public string SaleContactNumber { get; set; }

        public string Email { get; set; }

        public string DeliveryDate { get; set; }

        public string QuoteValidity { get; set; }

        public string TermOfPayment { get; set; }

        public string ApprovedBy { get; set; }

        public string QuotationRefNo { get; set; }

        public string CustomerEmail { get; set; }

        public string ContactPeriod { get; set; }
    }
}
