﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace FQ.API
{
    public sealed class QuotationItem
    {
        public string ItemName { get; set; }

        public string BuildingName { get; set; }

        public string Address { get; set; }

        public string Media { get; set; }

        public string Speed { get; set; }

        public string Router { get; set; }

        public int Price { get; set; }
    }
}
